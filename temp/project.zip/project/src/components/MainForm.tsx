// MainForm.tsx
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { downloadActualPDF } from "@/utils/pdfUtils";
import { initiatePayment } from "@/utils/razorpay";
import { getExamTypeDisplayName } from "@/utils/examTypeMapping";
import PaymentSuccessDialog from "@/components/PaymentSuccessDialog";

interface DatabasePaper {
  id: string;
  title: string;
  paper_type: string;
  class_level: string;
  exam_type: string;
  subject: string;
  file_url: string;
  file_name: string;
  is_active: boolean;
  created_at: string;
  standard: string;
  display_order: number;
}

interface PDFPaper {
  id: string;
  title: string;
  paper_type: "question" | "answer";
  standard: "10th" | "11th" | "12th";
  exam_type: "unit1" | "term1" | "unit2" | "prelim1" | "prelim2" | "prelim3" | "term2" | "internal" | "chapter";
  subject: string;
  file_url: string;
  file_name: string;
  pricing?: {
    price: number;
    is_free: boolean;
  };
}

interface PaperWithPricing {
  id: string;
  subject: string;
  paper_pricing: Array<{
    price: number;
    is_free: boolean;
  }>;
}

const MainForm = () => {
  const [paperType, setPaperType] = useState("question");
  const [selectedClass, setSelectedClass] = useState("");
  const [selectedExam, setSelectedExam] = useState("");
  const [availableSubjects, setAvailableSubjects] = useState<string[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string[]>([]);
  const [standards, setStandards] = useState<
    Array<{
      id: string;
      code: string;
      display_order: number;
      is_active: boolean;
      created_at: string;
      updated_at: string;
    }>
  >([]);
  const [examTypes, setExamTypes] = useState<
    Array<{
      id: string;
      name: string;
      standard_id: string | null;
      display_order: number;
      is_active: boolean;
      created_at: string;
      updated_at: string;
    }>
  >([]);
  const [paperPricing, setPaperPricing] = useState<{
    [key: string]: { price: number; is_free: boolean };
  }>({});
  const [formData, setFormData] = useState({
    schoolName: "",
    fullName: "",
    email: "",
    mobile: "",
  });
  const [schoolNameError, setSchoolNameError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [pendingDownloads, setPendingDownloads] = useState<any[]>([]);

  const { toast } = useToast();

  // Fetch standards
  useEffect(() => {
    const fetchCatalogData = async () => {
      const { data: standardsData, error: standardsError } = await supabase
        .from("standards")
        .select("*")
        .eq("is_active", true)
        .order("display_order");

      if (standardsError) {
        console.error("Error loading standards:", standardsError);
      } else if (standardsData) {
        setStandards(standardsData);
      }
    };

    fetchCatalogData();
  }, []);

  // Load exam types based on selected class
  useEffect(() => {
    const loadExamTypes = async () => {
      if (!selectedClass || selectedClass === "Select Class..") {
        setExamTypes([]);
        return;
      }

      const { data: standardData, error: standardError } = await supabase
        .from("standards")
        .select("id")
        .eq("code", selectedClass)
        .single();

      if (standardError || !standardData) {
        console.error("Error loading standard:", standardError);
        setExamTypes([]);
        return;
      }

      const { data, error } = await supabase
        .from("exam_types")
        .select("*")
        .eq("standard_id", standardData.id)
        .eq("is_active", true)
        .order("display_order");

      if (error) {
        console.error("Error loading exam types:", error);
        toast({
          title: "Error",
          description: "Error loading exam types",
          variant: "destructive",
        });
        return;
      }

      setExamTypes(data || []);
    };

    loadExamTypes();
  }, [selectedClass, toast]);

  // Load subjects for selected combination
  useEffect(() => {
    const loadAvailableSubjects = async () => {
      if (!selectedClass || !selectedExam || !paperType) {
        setAvailableSubjects([]);
        setPaperPricing({});
        return;
      }

      const { data, error } = await supabase
        .from("papers")
        .select(
          `
          subject,
          id,
          paper_pricing(price, is_free)
        `,
        )
        .eq("standard", selectedClass)
        .eq("exam_type", selectedExam)
        .eq("paper_type", paperType)
        .eq("is_active", true);

      if (error) {
        console.error("Error fetching papers:", error);
        setAvailableSubjects([]);
        setPaperPricing({});
        return;
      }

      const uniqueSubjects = [...new Set(data?.map((paper: any) => paper.subject) || [])];
      setAvailableSubjects(uniqueSubjects);

      const pricingMap: { [key: string]: { price: number; is_free: boolean } } = {};
      data?.forEach((paper: any) => {
        const paperData = paper as PaperWithPricing;
        const key = `${selectedClass}-${selectedExam}-${paperType}-${paperData.subject}`;
        if (paperData.paper_pricing && paperData.paper_pricing.length > 0) {
          pricingMap[key] = {
            price: paperData.paper_pricing[0].price,
            is_free: paperData.paper_pricing[0].is_free,
          };
        } else {
          pricingMap[key] = { price: 0, is_free: true };
        }
      });
      setPaperPricing(pricingMap);
    };

    if (examTypes.length > 0) {
      loadAvailableSubjects();
    }
  }, [selectedClass, selectedExam, paperType, examTypes]);

  const handleSubjectChange = (subject: string) => {
    setSelectedSubject((prev) => {
      if (prev.includes(subject)) {
        return prev.filter((s) => s !== subject);
      } else {
        return [...prev, subject];
      }
    });
  };

  const getPaperPricing = (subject: string) => {
    const key = `${selectedClass}-${selectedExam}-${paperType}-${subject}`;
    const pricing = paperPricing[key];

    if (!pricing) {
      return { price: 0, is_free: true, available: true };
    }

    return { ...pricing, available: true };
  };

  const getTotalAmount = () => {
    if (!selectedSubject.length) return 0;
    return selectedSubject.reduce((total, subject) => {
      const pricing = getPaperPricing(subject);
      return total + (pricing.is_free ? 0 : pricing.price);
    }, 0);
  };

  const handlePaymentSuccess = async (paymentId: string, orderId: string) => {
    try {
      for (const subject of selectedSubject) {
        const pricing = getPaperPricing(subject);
        const { error: transactionError } = await supabase.from("payment_transactions").insert({
          user_email: formData.email,
          user_name: formData.fullName,
          school_name: formData.schoolName,
          mobile: formData.mobile,
          paper_id: subject,
          razorpay_payment_id: paymentId,
          razorpay_order_id: orderId,
          amount: pricing.is_free ? 0 : pricing.price,
          status: "completed",
        });
        if (transactionError) {
          console.error("Error creating payment record for subject:", subject, transactionError);
        }
      }

      // Store papers for later download
      const papers = [];
      for (const subject of selectedSubject) {
        const { data, error } = await supabase
          .from("papers")
          .select("*")
          .eq("standard", selectedClass)
          .eq("exam_type", selectedExam)
          .eq("paper_type", paperType)
          .eq("subject", subject)
          .eq("is_active", true)
          .order("display_order")
          .limit(1);

        if (!error && data && data.length > 0) {
          papers.push(data[0]);
        }
      }

      setPendingDownloads(papers);
      await sendPDFsToEmail();
      setShowSuccessDialog(true);
    } catch (error) {
      console.error("Error processing payment success:", error);
      toast({
        title: "Error",
        description: "Payment successful but there was an issue. Please contact support.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadFromDialog = async () => {
    setShowSuccessDialog(false);
    setIsLoading(true);
    try {
      for (const paper of pendingDownloads) {
        await downloadActualPDF(
          {
            id: paper.id,
            title: paper.title,
            paper_type: paper.paper_type,
            standard: paper.standard,
            exam_type: paper.exam_type,
            subject: paper.subject,
            file_url: paper.file_url,
            file_name: paper.file_name,
          },
          {
            collegeName: formData.schoolName,
            email: formData.email,
            phone: formData.mobile,
          }
        );

        await supabase.from("download_logs").insert({
          paper_id: paper.id,
          user_email: formData.email,
          user_name: formData.fullName,
          school_name: formData.schoolName,
          mobile: formData.mobile,
        });
      }

      toast({
        title: "Download Complete!",
        description: "PDFs have been downloaded successfully.",
      });
    } catch (error) {
      console.error("Error downloading PDFs:", error);
      toast({
        title: "Download Error",
        description: "There was an issue downloading the PDFs. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoToTop = () => {
    setShowSuccessDialog(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePaymentError = (error: any) => {
    console.error("Payment failed:", error);
    toast({
      title: "Payment Failed",
      description: "Your payment could not be processed. Please try again.",
      variant: "destructive",
    });
  };

  const sendPDFsToEmail = async () => {
    if (!selectedSubject.length) return;

    for (const subject of selectedSubject) {
      const { data: papers, error } = await supabase
        .from("papers")
        .select("*")
        .eq("standard", selectedClass)
        .eq("exam_type", selectedExam)
        .eq("paper_type", paperType)
        .eq("subject", subject)
        .eq("is_active", true)
        .order("display_order")
        .limit(1);

      if (error || !papers || papers.length === 0) {
        console.error("Error fetching paper for email:", subject, error);
        continue;
      }

      const paper = papers[0] as DatabasePaper;

      const examTypeData = examTypes.find((e) => e.id === selectedExam);
      const examTypeName = examTypeData?.name || selectedExam;

      try {
        const { error: emailError } = await supabase.functions.invoke("send-pdf-email", {
          body: {
            userEmail: formData.email,
            userName: formData.fullName,
            schoolName: formData.schoolName,
            pdfUrl: paper.file_url,
            pdfFileName: paper.file_name,
            subject: paper.subject,
            standard: selectedClass,
            examType: examTypeName,
            paperType: paperType,
            adminEmail: "admin@smartabhyas.com",
          },
        });

        if (emailError) {
          console.error("Error sending email for subject:", subject, emailError);
        }
      } catch (err) {
        console.error("Failed to send email for subject:", subject, err);
      }
    }
  };

  const processDownloads = async () => {
    if (!selectedSubject.length) return;

    for (const subject of selectedSubject) {
      const { data: papers, error } = await supabase
        .from("papers")
        .select("*")
        .eq("standard", selectedClass)
        .eq("exam_type", selectedExam)
        .eq("paper_type", paperType)
        .eq("subject", subject)
        .eq("is_active", true)
        .order("display_order")
        .limit(1);

      if (error || !papers || papers.length === 0) {
        console.error("Error fetching paper for subject:", subject, error);
        continue;
      }

      const paper = papers[0] as DatabasePaper;

      const selectedStandardData = standards.find((s) => s.code === selectedClass);
      const standard = (selectedStandardData?.code as "10th" | "11th" | "12th") || "10th";

      const pdfPaper: PDFPaper = {
        id: paper.id,
        title: paper.title,
        paper_type: paperType as "question" | "answer",
        standard: standard,
        exam_type: selectedExam as
          | "unit1"
          | "term1"
          | "unit2"
          | "prelim1"
          | "prelim2"
          | "prelim3"
          | "term2"
          | "internal"
          | "chapter",
        subject: paper.subject,
        file_url: paper.file_url,
        file_name: paper.file_name,
      };

      const userInfo = {
        collegeName: formData.schoolName,
        email: formData.email,
        phone: formData.mobile || "",
      };

      const { error: logError } = await supabase.from("download_logs").insert({
        paper_id: paper.id,
        user_email: formData.email,
        user_name: formData.fullName,
        school_name: formData.schoolName,
        mobile: formData.mobile,
      });

      if (logError) {
        console.error("Error logging download:", logError);
      }

      await downloadActualPDF(pdfPaper, userInfo);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.schoolName.trim().length < 10) {
      setSchoolNameError("विद्यालय / कॉलेज नाव किमान 10 अक्षरांचे असावे");
      toast({
        title: "त्रुटी",
        description: "विद्यालय / कॉलेज नाव किमान 10 अक्षरांचे असावे",
        variant: "destructive",
      });
      return;
    }

    if (!selectedClass || !selectedExam || !selectedSubject.length || !formData.email || !formData.schoolName) {
      toast({
        title: "कृपया सर्व आवश्यक माहिती भरा",
        description: "सर्व आवश्यक फील्ड भरणे आवश्यक आहे",
        variant: "destructive",
      });
      return;
    }

    const totalAmount = getTotalAmount();

    if (totalAmount === 0) {
      setIsLoading(true);
      try {
        await processDownloads();
        toast({
          title: "Download सुरू केली गेली!",
          description: "तुमची PDFs watermark सह download होत आहेत...",
        });
      } catch (error) {
        console.error("Error processing downloads:", error);
        toast({
          title: "Error",
          description: "काहीतरी चूक झाली. कृपया पुन्हा प्रयत्न करा.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
      return;
    }

    setIsLoading(true);

    try {
      const totalAmount = getTotalAmount();
      if (totalAmount <= 0) {
        throw new Error("Invalid payment amount");
      }

      await initiatePayment(
        totalAmount,
        selectedSubject.join(", "),
        {
          name: formData.fullName || "User",
          email: formData.email,
          phone: formData.mobile || "",
          schoolName: formData.schoolName,
        },
        handlePaymentSuccess,
        handlePaymentError,
      );
    } catch (error) {
      console.error("Error initiating payment:", error);
      toast({
        title: "Error",
        description: "Payment could not be initiated. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // --- UI helper: ultra-simple fallback override for 12th + chapterwise
  const renderExamName = (name: string) => {
    if (
      selectedClass === "12th" &&
      (name || "")
        .normalize("NFKC")
        .replace(/[\u200B-\u200D\uFEFF]/g, "")
        .includes("प्रकरण")
    ) {
      // Safety net: still show Feb/Mar 2023 if mapping missed
      return "फेब्रुवारी / मार्च 2023";
    }
    return getExamTypeDisplayName(name, selectedClass);
  };

  return (
    <section className="mb-5">
      <div className="row">
        <div className="col-lg-6 mb-4 mb-lg-0">
          <div className="card h-100">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="radio-toolbar">
                  <input
                    type="radio"
                    id="type_question"
                    name="paper_type"
                    value="question"
                    checked={paperType === "question"}
                    onChange={(e) => {
                      setPaperType(e.target.value);
                      setSelectedSubject([]);
                      setAvailableSubjects([]);
                    }}
                  />
                  <label htmlFor="type_question">प्रश्नपत्रिका</label>

                  <input
                    type="radio"
                    id="type_answer"
                    name="paper_type"
                    value="answer"
                    checked={paperType === "answer"}
                    onChange={(e) => {
                      setPaperType(e.target.value);
                      setSelectedSubject([]);
                      setAvailableSubjects([]);
                    }}
                  />
                  <label htmlFor="type_answer">उत्तरपत्रिका</label>
                </div>

                <div className="mb-3">
                  <label htmlFor="class" className="form-label">
                    इयत्ता
                  </label>
                  <select
                    id="class"
                    className="form-select"
                    value={selectedClass}
                    onChange={(e) => {
                      setSelectedClass(e.target.value);
                      setSelectedExam("");
                      setSelectedSubject([]);
                      setAvailableSubjects([]);
                    }}
                  >
                    <option value="">इयत्ता निवडा</option>
                    {standards.map((standard) => (
                      <option key={standard.id} value={standard.code}>
                        {standard.code}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="mb-3">
                  <label htmlFor="exam" className="form-label">
                    परीक्षा निवडा
                  </label>
                  <select
                    id="exam"
                    className="form-select"
                    value={selectedExam}
                    onChange={(e) => {
                      setSelectedExam(e.target.value);
                      setSelectedSubject([]);
                    }}
                    disabled={!selectedClass}
                  >
                    <option value="">परीक्षा निवडा</option>
                    {examTypes.map((exam) => (
                      <option key={exam.id} value={exam.id}>
                        {renderExamName(exam.name)}
                      </option>
                    ))}
                  </select>
                </div>

                {availableSubjects.length > 0 && (
                  <div className="mb-3">
                    <label className="form-label">उपलब्ध विषय निवडा</label>
                    <div className="subject-grid">
                      {availableSubjects.map((subject) => {
                        const pricing = getPaperPricing(subject);
                        return (
                          <div key={subject} className="subject-checkbox">
                            <input
                              type="checkbox"
                              id={subject}
                              checked={selectedSubject.includes(subject)}
                              onChange={() => handleSubjectChange(subject)}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <label htmlFor={subject}>
                              {subject}
                              {!pricing.is_free ? (
                                <span className="text-green-600 font-semibold ml-2">(₹{pricing.price})</span>
                              ) : (
                                <span className="text-blue-600 font-semibold ml-2">(Free)</span>
                              )}
                            </label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {availableSubjects.length === 0 && selectedClass && selectedExam && (
                  <div className="mb-3">
                    <p className="text-muted">या परीक्षेसाठी कोणतेही विषय उपलब्ध नाहीत.</p>
                  </div>
                )}

                <div className="mb-3">
                  <label htmlFor="school_name" className="form-label">
                    विद्यालय / कॉलेज नाव
                  </label>
                  <input
                    type="text"
                    id="school_name"
                    className={`form-control ${schoolNameError ? "border-red-500" : ""}`}
                    value={formData.schoolName}
                    onChange={(e) => {
                      setFormData({ ...formData, schoolName: e.target.value });
                      if (e.target.value.trim().length >= 10) {
                        setSchoolNameError("");
                      }
                    }}
                    minLength={10}
                    required
                  />
                  {schoolNameError && <small className="text-red-500 mt-1 block">{schoolNameError}</small>}
                  <small className="text-muted mt-1 block">किमान 10 अक्षरे आवश्यक</small>
                </div>

                <h5 className="mt-4 mb-3">वैयक्तिक माहिती</h5>

                <div className="mb-3">
                  <label htmlFor="full_name" className="form-label">
                    नाव
                  </label>
                  <input
                    type="text"
                    id="full_name"
                    className="form-control"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  />
                </div>

                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="email" className="form-label">
                      ई-मेल
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="form-control"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label htmlFor="mobile" className="form-label">
                      मोबाईल
                    </label>
                    <input
                      type="tel"
                      id="mobile"
                      className="form-control"
                      value={formData.mobile}
                      onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    />
                  </div>
                </div>

                {selectedSubject.length > 0 && (
                  <div className="mb-3 p-3 bg-gray-50 rounded">
                    <h6 className="font-semibold mb-2">Selected Papers ({selectedSubject.length}):</h6>
                    <div className="space-y-2">
                      {selectedSubject.map((subject) => {
                        const pricing = getPaperPricing(subject);
                        return (
                          <div key={subject} className="flex justify-between items-center">
                            <span>{subject}</span>
                            <span className={pricing.is_free ? "text-blue-600" : "text-green-600"}>
                              {pricing.is_free ? "Free" : `₹${pricing.price}`}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                    <hr className="my-2" />
                    <div className="flex justify-between items-center font-bold">
                      <span>Total Amount:</span>
                      <span className="text-green-600">₹{getTotalAmount()}</span>
                    </div>
                  </div>
                )}

                <div className="text-center mt-4">
                  <button type="submit" className="btn btn-primary btn-lg px-4" disabled={isLoading}>
                    {isLoading
                      ? "Processing..."
                      : getTotalAmount() > 0
                        ? `Pay ₹${getTotalAmount()} & Download`
                        : "Download करा"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="card h-100">
            <div className="card-body">
              <h3 className="text-primary mb-4">Highlights Of Smart Abhyas</h3>
              <ul className="feature-list">
                <li>
                  <i className="fas fa-check-circle"></i> Maharashtra State Board Syllabus
                </li>
                <li>
                  <i className="fas fa-check-circle"></i> Question Papers of All Exams Available
                </li>
                <li>
                  <i className="fas fa-check-circle"></i> Que. Papers With School/College/Institute Name
                </li>
                <li>
                  <i className="fas fa-check-circle"></i> Fully Solved Answers
                </li>
                <li>
                  <i className="fas fa-check-circle"></i> High Quality PDF Format
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <PaymentSuccessDialog
        open={showSuccessDialog}
        onDownload={handleDownloadFromDialog}
        onGoToTop={handleGoToTop}
      />
    </section>
  );
};

export default MainForm;
