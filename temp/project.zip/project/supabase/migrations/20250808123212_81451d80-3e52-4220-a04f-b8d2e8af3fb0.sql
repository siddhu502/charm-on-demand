-- Update exam types with meaningful names
UPDATE exam_types SET name = 'प्रथम घटक चाचणी परीक्षा' WHERE id = 'ad1f9a3d-b7cc-4c88-82aa-157921f0f192';
UPDATE exam_types SET name = 'द्वितीय घटक चाचणी परीक्षा' WHERE id = '71896ac3-3667-4cea-bc45-940559f2afa5';
UPDATE exam_types SET name = 'तृतीय घटक चाचणी परीक्षा' WHERE id = '648a1d64-6662-4e7c-99e2-52a45ca42f03';
UPDATE exam_types SET name = 'प्रथम सत्रांत परीक्षा' WHERE id = '2d052847-70ac-4514-96e8-ed26527a39d2';
UPDATE exam_types SET name = 'द्वितीय सत्रांत परीक्षा' WHERE id = 'a29a6272-544e-4dd9-987c-70ff7fca59b5';
UPDATE exam_types SET name = 'प्राथमिक परीक्षा १' WHERE id = 'a704c122-2f48-4e12-b5c2-cabb6b0a86ee';
UPDATE exam_types SET name = 'प्राथमिक परीक्षा २' WHERE id = 'ebc21208-8074-4cf6-ac1b-7b0241276c62';
UPDATE exam_types SET name = 'प्राथमिक परीक्षा ३' WHERE id = '55f44db5-6e1a-4748-9dee-600aca257065';
UPDATE exam_types SET name = 'अंतर्गत मूल्यमापन' WHERE id = 'a0b7796a-b459-4dec-90c1-c113502729eb';